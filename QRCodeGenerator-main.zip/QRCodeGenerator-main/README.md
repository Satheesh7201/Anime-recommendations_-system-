https://mohammadibbu.github.io/QRCodeGenerator/
